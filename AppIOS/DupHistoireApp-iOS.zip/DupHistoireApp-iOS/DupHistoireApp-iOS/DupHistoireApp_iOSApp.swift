//
//  DupHistoireApp_iOSApp.swift
//  DupHistoireApp-iOS
//
//  Created by Guillaume DUPUIS on 05/04/2025.
//

import SwiftUI

@main
struct DupHistoireApp_iOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
