//
//  DupHistoireApp_iOSTests.swift
//  DupHistoireApp-iOSTests
//
//  Created by Guillaume DUPUIS on 05/04/2025.
//

import Testing
@testable import DupHistoireApp_iOS

struct DupHistoireApp_iOSTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
